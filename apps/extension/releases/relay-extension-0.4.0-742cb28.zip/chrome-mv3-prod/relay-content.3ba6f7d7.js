var e,t;"function"==typeof(e=globalThis.define)&&(t=e,e=null),function(t,a,r,n,o){var i="undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:"undefined"!=typeof window?window:"undefined"!=typeof global?global:{},s="function"==typeof i[n]&&i[n],l=s.cache||{},c="undefined"!=typeof module&&"function"==typeof module.require&&module.require.bind(module);function p(e,a){if(!l[e]){if(!t[e]){var r="function"==typeof i[n]&&i[n];if(!a&&r)return r(e,!0);if(s)return s(e,!0);if(c&&"string"==typeof e)return c(e);var o=Error("Cannot find module '"+e+"'");throw o.code="MODULE_NOT_FOUND",o}u.resolve=function(a){var r=t[e][1][a];return null!=r?r:a},u.cache={};var d=l[e]=new p.Module(e);t[e][0].call(d.exports,u,d,d.exports,this)}return l[e].exports;function u(e){var t=u.resolve(e);return!1===t?{}:p(t)}}p.isParcelRequire=!0,p.Module=function(e){this.id=e,this.bundle=p,this.exports={}},p.modules=t,p.cache=l,p.parent=s,p.register=function(e,a){t[e]=[function(e,t){t.exports=a},{}]},Object.defineProperty(p,"root",{get:function(){return i[n]}}),i[n]=p;for(var d=0;d<a.length;d++)p(a[d]);if(r){var u=p(r);"object"==typeof exports&&"undefined"!=typeof module?module.exports=u:"function"==typeof e&&e.amd?e(function(){return u}):o&&(this[o]=u)}}({eOyul:[function(e,t,a){var r=e("@parcel/transformer-js/src/esmodule-helpers.js");r.defineInteropFlag(a),r.export(a,"config",()=>n),e("../src/content/adapter-runtime"),e("../static/relay-content.js");let n={matches:["https://chatgpt.com/*","https://chat.openai.com/*","https://perplexity.ai/*","https://www.perplexity.ai/*","https://codex.openai.com/*","https://claude.ai/*","https://gemini.google.com/*","https://aistudio.google.com/*","https://grok.com/*","https://chat.deepseek.com/*"],run_at:"document_end"}},{"../src/content/adapter-runtime":"8oXrU","../static/relay-content.js":"axEBV","@parcel/transformer-js/src/esmodule-helpers.js":"cHUbl"}],"8oXrU":[function(e,t,a){var r=e("@parcel/transformer-js/src/esmodule-helpers.js");r.defineInteropFlag(a),r.export(a,"installRelayAdapterRuntime",()=>i);var n=e("@relay/adapters");function o(e=window.location.href){return(0,n.resolveAdapter)(e)}function i(){window.__relayAdapterRuntime={resolve(e=window.location.href){let t=o(e);return t?{platform:t.getPlatform()}:null},collectTurns(e=document,t=window.location.href){let a=o(t);return a?.extractVisibleTurns(e)??[]},getPageMetadata(e=document,t=window.location.href){let a=o(t);return a?.getPageMetadata(e)??null},findPrompt(e=document,t=window.location.href){let a=o(t);return a?.findPromptInput(e)??null},async insertText(e,t=document,a=window.location.href){let r=o(a);return r?r.insertTextIntoPrompt(e,t):{ok:!1,reason:"Unsupported site."}},getLatestUserMessage(e=document,t=window.location.href){let a=o(t);if(!a)return null;let r=a.extractVisibleTurns(e),n=[...r].reverse().find(e=>"user"===e.role);return n?.content&&n.content.length>=5?n.content:null}}}try{i()}catch(e){console.error("[Relay] Failed to install adapter runtime:",e)}},{"@relay/adapters":"fCop2","@parcel/transformer-js/src/esmodule-helpers.js":"cHUbl"}],fCop2:[function(e,t,a){var r=e("@parcel/transformer-js/src/esmodule-helpers.js");r.defineInteropFlag(a);var n=e("./chatgpt/adapter");r.exportAll(n,a);var o=e("./claude/adapter");r.exportAll(o,a);var i=e("./codex/adapter");r.exportAll(i,a);var s=e("./deepseek/adapter");r.exportAll(s,a);var l=e("./gemini/adapter");r.exportAll(l,a);var c=e("./grok/adapter");r.exportAll(c,a);var p=e("./perplexity/adapter");r.exportAll(p,a);var d=e("./registry/adapter-registry");r.exportAll(d,a)},{"./chatgpt/adapter":"k17BJ","./claude/adapter":"4RDBW","./codex/adapter":"ekSe0","./deepseek/adapter":"80afU","./gemini/adapter":"7Cnwt","./grok/adapter":"8QT3s","./perplexity/adapter":"knCeH","./registry/adapter-registry":"iifix","@parcel/transformer-js/src/esmodule-helpers.js":"cHUbl"}],k17BJ:[function(e,t,a){var r=e("@parcel/transformer-js/src/esmodule-helpers.js");r.defineInteropFlag(a),r.export(a,"ChatgptAdapter",()=>s);var n=e("../base/site-adapter"),o=e("../base/dom-utils"),i=e("./selectors");class s extends n.BaseSiteAdapter{canHandle(e){let t=new URL(e);return!!/chatgpt\.com|chat\.openai\.com/.test(t.hostname)&&!("codex.openai.com"===t.hostname||"/codex"===t.pathname||t.pathname.startsWith("/codex/"))}getPlatform(){return"chatgpt"}extractVisibleTurns(e=document){return(0,o.collectTurns)(e,i.chatgptTurnSelectors).map(({contentHash:e,...t})=>t)}findPromptInput(e=document){return(0,o.findPrompt)(e,i.chatgptPromptSelectors)}async insertTextIntoPrompt(e,t=document){let a=this.findPromptInput(t);return a?(0,o.injectText)(a,e):{ok:!1,reason:"Prompt not found."}}getPageMetadata(e=document){var t;let a=new URL(e.location.href);return{title:e.title,url:a.toString(),pathname:a.pathname,pageFingerprint:a.pathname.split("/").pop()??null,domain:a.hostname,routeKind:"/"===(t=a.pathname)?"fresh":/^\/g\/[^/]+\/project\/?$/.test(t)||/^\/g\/[^/]+\/?$/.test(t)?"project_root":"chat"}}}},{"../base/site-adapter":"2QGsn","../base/dom-utils":"jfGye","./selectors":"aqjAy","@parcel/transformer-js/src/esmodule-helpers.js":"cHUbl"}],"2QGsn":[function(e,t,a){var r=e("@parcel/transformer-js/src/esmodule-helpers.js");r.defineInteropFlag(a),r.export(a,"BaseSiteAdapter",()=>n);class n{}},{"@parcel/transformer-js/src/esmodule-helpers.js":"cHUbl"}],cHUbl:[function(e,t,a){a.interopDefault=function(e){return e&&e.__esModule?e:{default:e}},a.defineInteropFlag=function(e){Object.defineProperty(e,"__esModule",{value:!0})},a.exportAll=function(e,t){return Object.keys(e).forEach(function(a){"default"===a||"__esModule"===a||t.hasOwnProperty(a)||Object.defineProperty(t,a,{enumerable:!0,get:function(){return e[a]}})}),t},a.export=function(e,t,a){Object.defineProperty(e,t,{enumerable:!0,get:a})}},{}],jfGye:[function(e,t,a){var r=e("@parcel/transformer-js/src/esmodule-helpers.js");r.defineInteropFlag(a),r.export(a,"collectTurns",()=>o),r.export(a,"findPrompt",()=>i),r.export(a,"injectText",()=>l);var n=e("@relay/shared/utils/text");function o(e,t,a){return t.flatMap(t=>Array.from(e.querySelectorAll(t))).filter((e,t,a)=>a.indexOf(e)===t).map((e,t)=>({role:a?.(e)??e.getAttribute("data-message-author-role")??"unknown",content:(0,n.normalizeText)(e.textContent??""),turnIndex:t,rawHtml:e.innerHTML,contentHash:function(e){let t=0;for(let a=0;a<e.length;a+=1)t=(t<<5)-t+e.charCodeAt(a)|0;return String(t)}((0,n.normalizeText)(e.textContent??""))})).filter(e=>e.content.length>0)}function i(e,t){for(let a of t){let t=Array.from(e.querySelectorAll(a));for(let e of t)if(function(e){let t=e.getBoundingClientRect(),a=window.getComputedStyle(e),r=/jsdom/i.test(e.ownerDocument.defaultView?.navigator?.userAgent??"");return(r||t.width>0&&t.height>0)&&"hidden"!==a.visibility&&"none"!==a.display&&!e.hasAttribute("disabled")}(e))return{element:e,isContentEditable:e.isContentEditable||"true"===e.contentEditable||"true"===e.getAttribute("contenteditable")}}return null}async function s(e,t){let a=Date.now()+350;for(;Date.now()<=a;){if((0,n.normalizeText)(e()).includes(t))return!0;await new Promise(e=>setTimeout(e,25))}return(0,n.normalizeText)(e()).includes(t)}async function l(e,t){let a=(0,n.normalizeText)(t);if(e.isContentEditable){e.element.focus();let r=window.getSelection(),n=document.createRange();n.selectNodeContents(e.element),r?.removeAllRanges(),r?.addRange(n);let o=!1;return"function"==typeof document.execCommand&&(o=document.execCommand("insertText",!1,t)),o||(e.element.textContent=t),e.element.dispatchEvent(new InputEvent("beforeinput",{bubbles:!0,cancelable:!0,data:t,inputType:"insertText"})),e.element.dispatchEvent(new InputEvent("input",{bubbles:!0,data:t,inputType:"insertText"})),e.element.dispatchEvent(new Event("change",{bubbles:!0})),await s(()=>e.element.textContent??"",a)?{ok:!0}:{ok:!1,reason:"Prompt editor did not accept the inserted text."}}if("value"in e.element){let r=e.element;r.focus();let n=r instanceof HTMLTextAreaElement?HTMLTextAreaElement.prototype:r instanceof HTMLInputElement?HTMLInputElement.prototype:null,o=n?Object.getOwnPropertyDescriptor(n,"value"):null;return o?.set?o.set.call(r,t):r.value=t,r.dispatchEvent(new InputEvent("beforeinput",{bubbles:!0,cancelable:!0,data:t,inputType:"insertText"})),r.dispatchEvent(new InputEvent("input",{bubbles:!0,data:t,inputType:"insertText"})),r.dispatchEvent(new Event("change",{bubbles:!0})),await s(()=>r.value,a)?{ok:!0}:{ok:!1,reason:"Prompt textarea did not accept the inserted text."}}return{ok:!1,reason:"No editable prompt field found."}}},{"@relay/shared/utils/text":"9kaH5","@parcel/transformer-js/src/esmodule-helpers.js":"cHUbl"}],"9kaH5":[function(e,t,a){var r=e("@parcel/transformer-js/src/esmodule-helpers.js");function n(e){return e.replace(/\s+/g," ").trim()}function o(e){let t=e.match(/^(.+?)\s*->\s*(.+)$/);if(!t)return e.trim()||null;let a=t[2].trim();return!a||/^none\.?$/i.test(a)?null:a}function i(e,t){if(e.length<=t)return e;let a=e.slice(0,t),r=a.lastIndexOf(".");if(r>.5*t)return a.slice(0,r+1);let n=a.lastIndexOf(" ");return n>.3*t?a.slice(0,n)+"...":a+"..."}function s(e){let t=e.replace(/^(#{1,6})\s/gm,"\\$1 "),a=(t.match(/\*/g)||[]).length;a%2!=0&&(t=t.replace(/\*/g,"\\*"));let r=(t.match(/_/g)||[]).length;return r%2!=0&&(t=t.replace(/_/g,"\\_")),t}function l(e){return n(e).toLowerCase().replace(/[^a-z0-9]+/g,"-").replace(/^-+|-+$/g,"")}r.defineInteropFlag(a),r.export(a,"normalizeText",()=>n),r.export(a,"stripArrowNotation",()=>o),r.export(a,"truncateSentence",()=>i),r.export(a,"escapeMarkdownInline",()=>s),r.export(a,"slugify",()=>l)},{"@parcel/transformer-js/src/esmodule-helpers.js":"cHUbl"}],aqjAy:[function(e,t,a){var r=e("@parcel/transformer-js/src/esmodule-helpers.js");r.defineInteropFlag(a),r.export(a,"chatgptTurnSelectors",()=>n),r.export(a,"chatgptPromptSelectors",()=>o);let n=["[data-message-author-role]"],o=["#prompt-textarea","form #prompt-textarea","form [contenteditable='true']","form textarea","main textarea","[contenteditable='true']"]},{"@parcel/transformer-js/src/esmodule-helpers.js":"cHUbl"}],"4RDBW":[function(e,t,a){var r=e("@parcel/transformer-js/src/esmodule-helpers.js");r.defineInteropFlag(a),r.export(a,"ClaudeAdapter",()=>s);var n=e("../base/site-adapter"),o=e("../base/dom-utils"),i=e("./selectors");class s extends n.BaseSiteAdapter{canHandle(e){return/claude\.ai/.test(e)}getPlatform(){return"claude"}extractVisibleTurns(e=document){return(0,o.collectTurns)(e,i.claudeTurnSelectors,e=>"message-human"===e.getAttribute("data-testid")?"user":"assistant").map(({contentHash:e,...t})=>t)}findPromptInput(e=document){return(0,o.findPrompt)(e,i.claudePromptSelectors)}async insertTextIntoPrompt(e,t=document){let a=this.findPromptInput(t);return a?(0,o.injectText)(a,e):{ok:!1,reason:"Prompt not found."}}getPageMetadata(e=document){let t=new URL(e.location.href),a="chat";return t.pathname.includes("/new")?a="fresh":/^\/project\/[^/]+\/?$/.test(t.pathname)&&(a="project_root"),{title:e.title,url:t.toString(),pathname:t.pathname,pageFingerprint:t.pathname.split("/").pop()??null,domain:t.hostname,routeKind:a}}}},{"../base/site-adapter":"2QGsn","../base/dom-utils":"jfGye","./selectors":"bYNkP","@parcel/transformer-js/src/esmodule-helpers.js":"cHUbl"}],bYNkP:[function(e,t,a){var r=e("@parcel/transformer-js/src/esmodule-helpers.js");r.defineInteropFlag(a),r.export(a,"claudeTurnSelectors",()=>n),r.export(a,"claudePromptSelectors",()=>o);let n=["main [data-testid='message-human']","main [data-testid='message-assistant']"],o=["div[contenteditable='true']","textarea"]},{"@parcel/transformer-js/src/esmodule-helpers.js":"cHUbl"}],ekSe0:[function(e,t,a){var r=e("@parcel/transformer-js/src/esmodule-helpers.js");r.defineInteropFlag(a),r.export(a,"CodexAdapter",()=>s);var n=e("../base/site-adapter"),o=e("../base/dom-utils"),i=e("./selectors");class s extends n.BaseSiteAdapter{canHandle(e){var t;return"codex.openai.com"===(t=new URL(e)).hostname||"/codex"===t.pathname||t.pathname.startsWith("/codex/")}getPlatform(){return"codex"}extractVisibleTurns(e=document){return(0,o.collectTurns)(e,i.codexTurnSelectors).map(({contentHash:e,...t})=>t)}findPromptInput(e=document){return(0,o.findPrompt)(e,i.codexPromptSelectors)}async insertTextIntoPrompt(e,t=document){let a=this.findPromptInput(t);return a?(0,o.injectText)(a,e):{ok:!1,reason:"Prompt not found."}}getPageMetadata(e=document){var t;let a=new URL(e.location.href);return{title:e.title,url:a.toString(),pathname:a.pathname,pageFingerprint:a.pathname.split("/").filter(Boolean).pop()??null,domain:a.hostname,routeKind:"/"===(t=a.pathname)||"/codex"===t||"/codex/"===t||"/codex/new"===t||"/new"===t?"fresh":"chat"}}}},{"../base/site-adapter":"2QGsn","../base/dom-utils":"jfGye","./selectors":"hzPJd","@parcel/transformer-js/src/esmodule-helpers.js":"cHUbl"}],hzPJd:[function(e,t,a){var r=e("@parcel/transformer-js/src/esmodule-helpers.js");r.defineInteropFlag(a),r.export(a,"codexTurnSelectors",()=>n),r.export(a,"codexPromptSelectors",()=>o);let n=["[data-message-author-role]"],o=["[data-type='unified-composer'] [contenteditable='true']","[data-type='unified-composer'] textarea","#prompt-textarea","form #prompt-textarea","form [contenteditable='true']","form textarea","main textarea","[contenteditable='true']"]},{"@parcel/transformer-js/src/esmodule-helpers.js":"cHUbl"}],"80afU":[function(e,t,a){var r=e("@parcel/transformer-js/src/esmodule-helpers.js");r.defineInteropFlag(a),r.export(a,"DeepseekAdapter",()=>s);var n=e("../base/site-adapter"),o=e("../base/dom-utils"),i=e("./selectors");class s extends n.BaseSiteAdapter{canHandle(e){return/chat\.deepseek\.com/.test(e)}getPlatform(){return"deepseek"}extractVisibleTurns(e=document){return(0,o.collectTurns)(e,i.deepseekTurnSelectors,e=>{let t=e.getAttribute("data-message-role");return"user"===t?"user":"assistant"===t?"assistant":e.classList.contains("ds-message")?e.querySelector(".ds-markdown")?"assistant":"user":"assistant"}).map(({contentHash:e,...t})=>t)}findPromptInput(e=document){return(0,o.findPrompt)(e,i.deepseekPromptSelectors)}async insertTextIntoPrompt(e,t=document){let a=this.findPromptInput(t);return a?(0,o.injectText)(a,e):{ok:!1,reason:"Prompt not found."}}getPageMetadata(e=document){let t=new URL(e.location.href),a="/"===t.pathname?"fresh":"chat";return{title:e.title,url:t.toString(),pathname:t.pathname,pageFingerprint:t.pathname.split("/").pop()??null,domain:t.hostname,routeKind:a}}}},{"../base/site-adapter":"2QGsn","../base/dom-utils":"jfGye","./selectors":"7NHD2","@parcel/transformer-js/src/esmodule-helpers.js":"cHUbl"}],"7NHD2":[function(e,t,a){var r=e("@parcel/transformer-js/src/esmodule-helpers.js");r.defineInteropFlag(a),r.export(a,"deepseekTurnSelectors",()=>n),r.export(a,"deepseekPromptSelectors",()=>o);let n=[".ds-message",".chat-message","[data-message-role]"],o=["textarea[placeholder*='Message']","textarea","[contenteditable='true']"]},{"@parcel/transformer-js/src/esmodule-helpers.js":"cHUbl"}],"7Cnwt":[function(e,t,a){var r=e("@parcel/transformer-js/src/esmodule-helpers.js");r.defineInteropFlag(a),r.export(a,"GeminiAdapter",()=>s);var n=e("../base/site-adapter"),o=e("../base/dom-utils"),i=e("./selectors");class s extends n.BaseSiteAdapter{canHandle(e){return/gemini\.google\.com|aistudio\.google\.com/.test(e)}getPlatform(){return"gemini"}extractVisibleTurns(e=document){return(0,o.collectTurns)(e,i.geminiTurnSelectors,e=>{let t=e.tagName?.toLowerCase()??"";if("user-query"===t||e.getAttribute("data-message-id")?.startsWith("user"))return"user";if("model-response"===t)return"assistant";if("ms-chat-turn"===t){let t=e.querySelector(".chat-turn-container");return t?.classList.contains("user")?"user":"assistant"}let a=e.getAttribute("data-message-author-role")??e.getAttribute("data-role");return"user"===a?"user":"assistant"}).map(({contentHash:e,...t})=>t)}findPromptInput(e=document){return(0,o.findPrompt)(e,i.geminiPromptSelectors)}async insertTextIntoPrompt(e,t=document){let a=this.findPromptInput(t);return a?(0,o.injectText)(a,e):{ok:!1,reason:"Prompt not found."}}getPageMetadata(e=document){var t;let a=new URL(e.location.href);return{title:e.title,url:a.toString(),pathname:a.pathname,pageFingerprint:a.pathname.split("/").pop()??null,domain:a.hostname,routeKind:"/app"===(t=a.pathname)||"/app/"===t||/^\/prompts\/new/.test(t)||"/prompts/new_chat"===t?"fresh":/^\/gems\/[^/]+/.test(t)?"project_root":/^\/app\/[^/]+/.test(t)||/^\/prompts\/[^/]+/.test(t)?"chat":"fresh"}}}},{"../base/site-adapter":"2QGsn","../base/dom-utils":"jfGye","./selectors":"97WQ8","@parcel/transformer-js/src/esmodule-helpers.js":"cHUbl"}],"97WQ8":[function(e,t,a){var r=e("@parcel/transformer-js/src/esmodule-helpers.js");r.defineInteropFlag(a),r.export(a,"geminiTurnSelectors",()=>n),r.export(a,"geminiPromptSelectors",()=>o);let n=["[data-message-id]",".conversation-container .message","model-response","user-query","message-content[data-message-id]",".chat-turn","ms-chat-turn"],o=[".ql-editor","rich-textarea [contenteditable='true']","[contenteditable='true']","textarea"]},{"@parcel/transformer-js/src/esmodule-helpers.js":"cHUbl"}],"8QT3s":[function(e,t,a){var r=e("@parcel/transformer-js/src/esmodule-helpers.js");r.defineInteropFlag(a),r.export(a,"GrokAdapter",()=>s);var n=e("../base/site-adapter"),o=e("../base/dom-utils"),i=e("./selectors");class s extends n.BaseSiteAdapter{canHandle(e){return/grok\.com|x\.com\/i\/grok/.test(e)}getPlatform(){return"grok"}extractVisibleTurns(e=document){let t=(0,o.collectTurns)(e,i.grokTurnSelectors,e=>{let t=e.getAttribute("data-message-role")??e.getAttribute("data-testid");return"user"===t||"user-message"===t?"user":"assistant"===t||"model"===t?"assistant":"unknown"}).map(({contentHash:e,...t})=>t),a=t.length>0&&t.every(e=>"unknown"===e.role);if(a)for(let e=0;e<t.length;e++){let a=t[e];a.role=e%2==0?"user":"assistant"}return t}findPromptInput(e=document){return(0,o.findPrompt)(e,i.grokPromptSelectors)}async insertTextIntoPrompt(e,t=document){let a=this.findPromptInput(t);return a?(0,o.injectText)(a,e):{ok:!1,reason:"Prompt not found."}}getPageMetadata(e=document){let t=new URL(e.location.href),a="/"===t.pathname||"/i/grok"===t.pathname?"fresh":"chat";return{title:e.title,url:t.toString(),pathname:t.pathname,pageFingerprint:t.pathname.split("/").pop()??null,domain:t.hostname,routeKind:a}}}},{"../base/site-adapter":"2QGsn","../base/dom-utils":"jfGye","./selectors":"fsnaf","@parcel/transformer-js/src/esmodule-helpers.js":"cHUbl"}],fsnaf:[function(e,t,a){var r=e("@parcel/transformer-js/src/esmodule-helpers.js");r.defineInteropFlag(a),r.export(a,"grokTurnSelectors",()=>n),r.export(a,"grokPromptSelectors",()=>o);let n=[".message-bubble","[data-testid='message']",".message-container","[data-message-role]","[role='article']"],o=["textarea","[contenteditable='true']","[role='textbox']"]},{"@parcel/transformer-js/src/esmodule-helpers.js":"cHUbl"}],knCeH:[function(e,t,a){var r=e("@parcel/transformer-js/src/esmodule-helpers.js");r.defineInteropFlag(a),r.export(a,"PerplexityAdapter",()=>s);var n=e("../base/site-adapter"),o=e("../base/dom-utils"),i=e("./selectors");class s extends n.BaseSiteAdapter{canHandle(e){return/perplexity\.ai/.test(e)}getPlatform(){return"perplexity"}extractVisibleTurns(e=document){return(0,o.collectTurns)(e,i.perplexityTurnSelectors,e=>"H1"===e.tagName||e.classList.contains("query")||e.className?.includes?.("query")?"user":e.classList.contains("prose")?"assistant":"query"===e.getAttribute("data-testid")?"user":"assistant").map(({contentHash:e,...t})=>t)}findPromptInput(e=document){return(0,o.findPrompt)(e,i.perplexityPromptSelectors)}async insertTextIntoPrompt(e,t=document){let a=this.findPromptInput(t);return a?(0,o.injectText)(a,e):{ok:!1,reason:"Prompt not found."}}getPageMetadata(e=document){let t=new URL(e.location.href),a="/"===t.pathname||"/search"===t.pathname||"/home"===t.pathname?"fresh":"chat";return{title:e.title,url:t.toString(),pathname:t.pathname,pageFingerprint:t.pathname.split("/").pop()??null,domain:t.hostname,routeKind:a}}}},{"../base/site-adapter":"2QGsn","../base/dom-utils":"jfGye","./selectors":"awBF4","@parcel/transformer-js/src/esmodule-helpers.js":"cHUbl"}],awBF4:[function(e,t,a){var r=e("@parcel/transformer-js/src/esmodule-helpers.js");r.defineInteropFlag(a),r.export(a,"perplexityTurnSelectors",()=>n),r.export(a,"perplexityPromptSelectors",()=>o);let n=["h1[class*='query']","main .prose","main [data-testid='query']","main [data-testid='answer']","[data-testid='thread-query']","[data-testid='thread-answer']",".pb-md [data-message-role]","[data-testid='search-result']"],o=["[role='textbox'][contenteditable='true']","textarea[placeholder*='Ask']","textarea[placeholder*='ask']","textarea[placeholder*='Follow']","textarea[placeholder*='follow']","#ppl-search-input","textarea","[contenteditable='true']"]},{"@parcel/transformer-js/src/esmodule-helpers.js":"cHUbl"}],iifix:[function(e,t,a){var r=e("@parcel/transformer-js/src/esmodule-helpers.js");r.defineInteropFlag(a),r.export(a,"resolveAdapter",()=>h),r.export(a,"listAdapters",()=>f);var n=e("../chatgpt/adapter"),o=e("../claude/adapter"),i=e("../codex/adapter"),s=e("../deepseek/adapter"),l=e("../gemini/adapter"),c=e("../grok/adapter"),p=e("../perplexity/adapter");let d=[new i.CodexAdapter,new n.ChatgptAdapter,new p.PerplexityAdapter,new o.ClaudeAdapter,new l.GeminiAdapter,new c.GrokAdapter,new s.DeepseekAdapter],u=/(^|\.)(chatgpt|openai|claude|perplexity|gemini|grok|deepseek)\.(com|ai|io)$/i,m=new Set;function h(e){let t=d.find(t=>t.canHandle(e))??null;return!t&&function(e){try{let{hostname:t}=new URL(e);if(!u.test(t)||m.has(t))return!1;return m.add(t),!0}catch{return!1}}(e)&&console.warn(`[relay-adapters] resolveAdapter returned null for a known AI host (${e}). Adapter registry may be out of date.`),t}function f(){return d}},{"../chatgpt/adapter":"k17BJ","../claude/adapter":"4RDBW","../codex/adapter":"ekSe0","../deepseek/adapter":"80afU","../gemini/adapter":"7Cnwt","../grok/adapter":"8QT3s","../perplexity/adapter":"knCeH","@parcel/transformer-js/src/esmodule-helpers.js":"cHUbl"}],axEBV:[function(e,t,a){!function(){let e="relay.themeMode";console.debug("[Relay] Content script loaded on",window.location.href);let t={chatgpt:{streamingSelectors:["button[aria-label*='Stop']","[data-testid='stop-button']"]},codex:{streamingSelectors:["button[aria-label*='Stop']","[data-testid='stop-button']"]},claude:{streamingSelectors:["[data-is-streaming='true']"]},perplexity:{streamingSelectors:["button[aria-label*='Stop']","[data-testid='stop-generating']"]},gemini:{streamingSelectors:["button[aria-label*='Stop']","[data-testid='stop-button']","mat-icon[data-mat-icon-name='stop_circle']"]},grok:{streamingSelectors:["button[aria-label*='Stop']","[data-testid='stop-button']"]},deepseek:{streamingSelectors:["button[aria-label*='Stop']",".stop-generating"]}},a={dismissed:!1,forcedVisible:!1,href:window.location.href,forcedInsertKind:null,projectSwitcherSurface:null,observationTimer:null,stabilityRecheckTimer:null,lastMeaningfulMutationAt:Date.now(),lastContentChangeAt:Date.now(),lastContentStabilityKey:"",freshCandidateSince:0,lastPageStateKey:"",pageState:null,currentState:null,buttonMode:"idle",buttonError:"",exitTimer:null,resetButtonTimer:null,mounted:!1,wasStreaming:!1,streamingEndedAt:0,associationToast:{payload:null,hideTimer:null,removeTimer:null,countdownTimer:null,paused:!1,remainingMs:null},themeMode:"system",resolvedTheme:window.matchMedia("(prefers-color-scheme: dark)").matches?"dark":"light"},r={latest:null,maxAgeMs:6e4};function n(e){a.themeMode=e,a.resolvedTheme="system"===e?window.matchMedia("(prefers-color-scheme: dark)").matches?"dark":"light":"light"===e?"light":"dark";let t=document.getElementById("relay-inline-chip");t&&(t.dataset.theme=a.resolvedTheme);let r=document.getElementById("relay-association-toast");r&&(r.dataset.theme=a.resolvedTheme)}async function o(){try{let t=await chrome.storage.local.get(e),a=t[e];n("light"===a||"dark"===a||"system"===a?a:"system")}catch(e){n("system")}}function i(e){return String(e).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#39;")}function s(e){return(e||"").replace(/\s+/g," ").trim()}function l(){return window.__relayAdapterRuntime||null}function c(e,t,a,r){let n=JSON.stringify({platform:a,identity:r||t.pageFingerprint||t.url,turns:e.map(e=>({role:e.role,content:s(e.content)}))}),o=0;for(let e=0;e<n.length;e+=1)o=(o<<5)-o+n.charCodeAt(e)|0;return String(o)}function p(){var e;let a=l(),r=a?a.resolve(window.location.href):null,n=r?r.platform:(e=window.location.href,/codex\.openai\.com/.test(e)||/chatgpt\.com\/codex|chat\.openai\.com\/codex/.test(e)?"codex":/chatgpt\.com|chat\.openai\.com/.test(e)?"chatgpt":/claude\.ai/.test(e)?"claude":/perplexity\.ai/.test(e)?"perplexity":/gemini\.google\.com|aistudio\.google\.com/.test(e)?"gemini":/grok\.com|x\.com\/i\/grok/.test(e)?"grok":/chat\.deepseek\.com/.test(e)?"deepseek":null);return n?{platform:n,streamingSelectors:t[n]?.streamingSelectors||[]}:null}function d(e,t){let a=l(),n=a?a.collectTurns(document,window.location.href):[],o=function(e,t,a){var n=r.latest;if(!n||Date.now()-n.capturedAt>r.maxAgeMs||n.platform!==t.platform)return h(e,"dom");var o=g(t.platform,a);if(n.conversationId&&o&&n.conversationId!==o)return h(e,"dom");if(n.url&&a&&a.url)try{var i=new URL(n.url),l=new URL(a.url);if(i.hostname===l.hostname&&i.pathname!==l.pathname&&!n.conversationId&&!o)return h(e,"dom")}catch(e){}var c=n.turns;if(!c||0===c.length||e.length>=c.length)return h(e,"dom");for(var p={},d=0;d<e.length;d++){var u=e[d];u&&null!=u.turnIndex&&(p[u.turnIndex]=u)}for(var m={},f=0;f<e.length;f++){var y=e[f];if(y&&y.content){var b=s(y.content).slice(0,80);b.length>=10&&(m[b]=y)}}for(var x=[],_=0;_<c.length;_++){var v=c[_];if(v){var w=m[s(v.content||"").slice(0,80)]||null;x.push({role:v.role,content:v.content,turnIndex:_,rawHtml:w?w.rawHtml:null,captureSource:w?"merged":"network"})}}return console.debug("[Relay] Merged network+DOM turns:",c.length,"network,",e.length,"DOM \u2192",x.length,"merged"),x}(n,e,t);return o}var u={maxTurnContent:12e4,maxRawHtml:25e4,maxTurns:500};function m(e){return e.slice(0,u.maxTurns).map(function(e){var t=Object.assign({},e);return"string"==typeof t.content&&t.content.length>u.maxTurnContent&&(t.content=t.content.slice(0,u.maxTurnContent-14)+"\n[\u2026truncated]"),t.content||(t.content="[empty]"),"string"==typeof t.rawHtml&&t.rawHtml.length>u.maxRawHtml&&(t.rawHtml=t.rawHtml.slice(0,u.maxRawHtml-14)+"\n[\u2026truncated]"),t})}function h(e,t){return e.map(function(e){return Object.assign({},e,{captureSource:t})})}function f(){let e=l(),t=e?e.getPageMetadata(document,window.location.href):null;if(t)return t;let a=new URL(window.location.href);return{title:document.title||null,url:a.toString(),pathname:a.pathname,pageFingerprint:a.pathname.split("/").filter(Boolean).pop()||null,domain:a.hostname,routeKind:null}}function g(e,t){return(r.latest&&r.latest.platform===e?r.latest.conversationId:null)||function(e,t){if(!e||!t||!t.url)return null;var a=t.url,r=null;return"chatgpt"===e?(r=a.match(/\/g\/[^/]+\/c\/([a-zA-Z0-9-]+)/))?r[1]:/\/g\/[a-zA-Z0-9-]+\/?$/.test(a)?null:(r=a.match(/\/c\/([a-zA-Z0-9-]+)/))?r[1]:null:"claude"===e&&/\/chat\/([a-zA-Z0-9-]+)/.test(a)?(r=a.match(/\/chat\/([a-zA-Z0-9-]+)/))?r[1]:null:"perplexity"===e&&/\/search\/([a-zA-Z0-9-]+)/.test(a)?(r=a.match(/\/search\/([a-zA-Z0-9-]+)/))?r[1]:null:"gemini"===e&&/\/app\/([a-zA-Z0-9_-]+)/.test(a)?(r=a.match(/\/app\/([a-zA-Z0-9_-]+)/))?r[1]:null:"grok"===e&&/conversation=([a-zA-Z0-9_-]+)/.test(a)?(r=a.match(/conversation=([a-zA-Z0-9_-]+)/))?r[1]:null:"deepseek"===e&&/\/s\/([a-zA-Z0-9_-]+)/.test(a)&&(r=a.match(/\/s\/([a-zA-Z0-9_-]+)/))?r[1]:null}(e,t)||t.pageFingerprint||null}let y={chatgpt:["#prompt-textarea","div[contenteditable='true']","textarea"],codex:["[data-type='unified-composer'] [contenteditable='true']","[data-type='unified-composer'] textarea","#prompt-textarea","div[contenteditable='true']","textarea"],claude:["div[contenteditable='true']","textarea"],perplexity:["textarea[placeholder*='Ask']","textarea","[contenteditable='true']"],gemini:[".ql-editor","rich-textarea [contenteditable='true']","[contenteditable='true']","textarea"],grok:["textarea","[contenteditable='true']"],deepseek:["textarea","[contenteditable='true']"]};function b(e){let t=l(),a=t?t.findPrompt(document,window.location.href):null;if(a)return a;let r=y[e.platform]||["div[contenteditable='true']","textarea"];for(let e of r){let t=document.querySelectorAll(e);for(let e of t){let t=e.getBoundingClientRect(),a=window.getComputedStyle(e);if(t.width>0&&t.height>0&&"hidden"!==a.visibility&&"none"!==a.display&&!e.hasAttribute("disabled"))return{element:e,isContentEditable:e.isContentEditable||"true"===e.contentEditable||"true"===e.getAttribute("contenteditable")}}}return null}async function x(e,t){let a=l();return a?a.insertText(t,document,window.location.href):{ok:!1,reason:"Prompt not found."}}function _(e){if(!e)return{supported:!1};let t=f(),r=d(e,t),n=m(r),o=b(e),i=function(e,t){if(t.routeKind&&"unknown"!==t.routeKind)return t.routeKind;let a=t.pathname||"/";return"claude"===e.platform?/^\/project\/[^/]+\/?$/.test(a)?"project_root":a.includes("/new")?"fresh":"chat":"gemini"===e.platform?"/app"===a||"/app/"===a||/^\/prompts\/new/.test(a)?"fresh":/^\/gems\/[^/]+/.test(a)?"project_root":/^\/app\/[^/]+/.test(a)?"chat":"fresh":"chatgpt"===e.platform||"codex"===e.platform?/^\/g\/[^/]+\/project\/?$/.test(a)||/^\/g\/[^/]+\/?$/.test(a)?"project_root":"/"===a?"fresh":"chat":"grok"===e.platform?"/"===a||"/i/grok"===a?"fresh":"chat":"/"===a?"fresh":"chat"}(e,t),l="fresh"===i,p=!!o,u=("fresh"===i||"project_root"===i)&&p&&0===r.length;u?a.freshCandidateSince||(a.freshCandidateSince=Date.now()):a.freshCandidateSince=0;let h=a.streamingEndedAt>0&&Date.now()-a.streamingEndedAt<1800,y=u&&Date.now()-a.freshCandidateSince>=800,x=g(e.platform,t),_=e.streamingSelectors.some(e=>document.querySelector(e)),v=c(n,t,e.platform,x),w=JSON.stringify({platform:e.platform,routeKind:i,pathname:t.pathname,sourceConversationId:x,turns:r.length,promptReady:p,isFreshRoute:l,isStreaming:_});a.lastContentStabilityKey!==w&&(a.lastContentStabilityKey=w,a.lastContentChangeAt=Date.now());let j=Date.now()-a.lastContentChangeAt;return{supported:!0,platform:e.platform,routeKind:i,title:t.title,url:t.url,domain:t.domain,pathname:t.pathname,pageFingerprint:t.pageFingerprint,sourceConversationId:x,turns:r.length,captureSignature:v,recentUserTurnText:function(e){for(let t=e.length-1;t>=0;t-=1){let a=e[t];if("user"===a.role&&a.content&&!(a.content.length<8))return a.content.slice(0,280)}return null}(r),recentRoutingText:function(e,t){let a=[],r=s(t);r&&a.push(r.slice(0,160));for(let t=e.length-1;t>=0&&a.length<5;t-=1){let r=e[t],n=s(r&&r.content);if(!n||n.length<8)continue;let o="assistant"===r.role?"assistant":"user";a.push(`${o}: ${n.slice(0,180)}`)}return 0===a.length?null:a.join("\n").slice(0,720)}(r,t.title),fullVisibleRoutingText:function(e,t){let a=[],r=s(t),n=0;if(r){let e=r.slice(0,200);a.push(e),n+=e.length}for(let t=0;t<e.length&&n<5976;t+=1){let r=e[t],o=s(r&&r.content);if(!o||o.length<3)continue;let i="assistant"===r.role?"assistant":"user",l=6e3-n-1;if(l<=24)break;let c=`${i}: ${o.slice(0,Math.min(220,l))}`;a.push(c),n+=c.length+1}return 0===a.length?null:a.join("\n").slice(0,6e3)}(r,t.title),promptReady:p,isFreshRoute:l,isFreshChat:y,isStable:j>=(h?800:1800),isStreaming:_}}function v(e){return!!(e&&"object"==typeof e&&e.page&&"boolean"==typeof e.page.supported&&Array.isArray(e.projectOptions))}function w(e){return new Promise(t=>{chrome.runtime.sendMessage(e,e=>{if(chrome.runtime.lastError){t({ok:!1,error:chrome.runtime.lastError.message});return}t(e)})})}function j(e){try{chrome.runtime.sendMessage({type:"RELAY_LOG_TELEMETRY",payload:{surface:"extension-inline-chip",url:window.location.pathname,timestamp:new Date().toISOString(),...e}})}catch(e){}}function T(){null!==a.exitTimer&&(window.clearTimeout(a.exitTimer),a.exitTimer=null),null!==a.resetButtonTimer&&(window.clearTimeout(a.resetButtonTimer),a.resetButtonTimer=null),null!==a.stabilityRecheckTimer&&(window.clearTimeout(a.stabilityRecheckTimer),a.stabilityRecheckTimer=null)}function k(e){return a.projectSwitcherSurface===e}function S(){a.projectSwitcherSurface=null}function A(){V(),a.associationToast.payload&&ee(a.associationToast.payload)}function I(e){a.projectSwitcherSurface=k(e)?null:e,A()}function E(){if(document.getElementById("relay-inline-chip-styles"))return;let e=document.createElement("style");e.id="relay-inline-chip-styles",e.textContent=`
      .relay-inline-chip {
        --relay-bg: #1a1a1c;
        --relay-surface: #202022;
        --relay-ink: #e4e4e7;
        --relay-ink-secondary: #b4b4bb;
        --relay-muted: #71717a;
        --relay-faint: #52525b;
        --relay-line: rgba(255, 255, 255, 0.07);
        --relay-accent: #e4e4e7;
        --relay-accent-text: #09090b;
        --relay-hover: rgba(255, 255, 255, 0.08);
        --relay-shadow: 0 4px 24px rgba(0, 0, 0, 0.5);
        --relay-tooltip-shadow: 0 8px 24px rgba(0, 0, 0, 0.2);
        min-width: 240px;
        max-width: min(90%, calc(100vw - 32px));
        border: 1px solid var(--relay-line);
        border-radius: 10px;
        background: var(--relay-bg);
        color: var(--relay-ink);
        box-shadow: var(--relay-shadow);
        font-family: system-ui, -apple-system, "Segoe UI", sans-serif;
        overflow: visible;
        z-index: 2147483000;
        opacity: 0;
        transform: translateY(6px);
        transition: opacity 140ms ease-out, transform 140ms ease-out;
      }

      .relay-inline-chip[data-theme="light"] {
        --relay-bg: #fafaf9;
        --relay-surface: #ffffff;
        --relay-ink: #0f0f0f;
        --relay-ink-secondary: #3a3a3a;
        --relay-muted: #737373;
        --relay-faint: #a3a3a3;
        --relay-line: rgba(0, 0, 0, 0.06);
        --relay-accent: #171717;
        --relay-accent-text: #fafafa;
        --relay-hover: rgba(0, 0, 0, 0.04);
        --relay-shadow: 0 1px 3px rgba(0, 0, 0, 0.05), 0 4px 12px rgba(0, 0, 0, 0.04);
        --relay-tooltip-shadow: 0 2px 8px rgba(0, 0, 0, 0.06), 0 12px 32px rgba(0, 0, 0, 0.08);
      }

      .relay-inline-chip--visible {
        opacity: 1;
        transform: translateY(0);
      }

      .relay-inline-chip--exiting {
        opacity: 0;
        transform: translateY(8px);
        transition: opacity 180ms ease-in-out, transform 180ms ease-in-out;
      }

      .relay-inline-chip--anchored {
        position: fixed;
        border-bottom-left-radius: 0;
        border-bottom-right-radius: 0;
        border-bottom: none;
      }

      .relay-inline-chip--floating {
        position: fixed;
        right: 16px;
        bottom: 16px;
      }

      .relay-inline-chip__body {
        position: relative;
        display: grid;
        grid-template-columns: 22px 1fr auto;
        grid-template-rows: auto auto;
        gap: 2px 10px;
        padding: 8px 12px;
        align-items: center;
      }

      /* \u2500\u2500 Close button: top-right corner \u2500\u2500 */
      .relay-inline-chip__close {
        position: absolute;
        top: 6px;
        right: 6px;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        width: 18px;
        height: 18px;
        border: none;
        border-radius: 4px;
        background: transparent;
        color: var(--relay-faint);
        font-size: 12px;
        line-height: 1;
        cursor: pointer;
        z-index: 2;
        transition: background 120ms, color 120ms;
      }

      .relay-inline-chip__close:hover {
        background: var(--relay-hover);
        color: var(--relay-ink);
      }

      /* \u2500\u2500 Logo: column 1, spans both rows, vertically centered \u2500\u2500 */
      .relay-inline-chip__logo {
        grid-column: 1;
        grid-row: 1 / 3;
        align-self: center;
        justify-self: center;
        width: 20px;
        height: 20px;
        flex-shrink: 0;
        object-fit: contain;
      }

      .relay-inline-chip[data-theme="dark"] .relay-inline-chip__logo,
      .relay-inline-chip:not([data-theme]) .relay-inline-chip__logo {
        filter: brightness(1);
      }

      .relay-inline-chip[data-theme="light"] .relay-inline-chip__logo {
        filter: brightness(0);
      }

      /* \u2500\u2500 Row 1: project picker (col 2) + insert button (col 3) \u2500\u2500 */
      .relay-inline-chip__row1 {
        grid-column: 2;
        grid-row: 1;
        display: flex;
        align-items: center;
        gap: 6px;
        min-width: 0;
      }

      .relay-inline-chip__titleWrap {
        position: relative;
        min-width: 0;
        flex: 1;
      }

      .relay-inline-chip__title {
        margin: 0;
        font-size: 12px;
        font-weight: 600;
        line-height: 1.3;
        letter-spacing: -0.01em;
      }

      .relay-inline-chip__titleButton {
        width: fit-content;
        max-width: 100%;
        display: inline-flex;
        align-items: center;
        gap: 4px;
        border: none;
        background: transparent;
        padding: 2px 0;
        color: inherit;
        cursor: pointer;
        font-size: inherit;
        font-family: inherit;
      }

      .relay-inline-chip__titleLabel {
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
      }

      .relay-inline-chip__titleChevron {
        width: 11px;
        height: 11px;
        color: var(--relay-faint);
        transition: transform 120ms ease, color 120ms ease;
      }

      .relay-inline-chip__titleButton:hover .relay-inline-chip__titleChevron,
      .relay-inline-chip__titleButton:focus-visible .relay-inline-chip__titleChevron {
        color: var(--relay-ink);
      }

      .relay-inline-chip__titleButton[aria-expanded="true"] .relay-inline-chip__titleChevron {
        transform: rotate(180deg);
      }

      /* \u2500\u2500 Insert button: col 3, spans both rows, vertically centered \u2500\u2500 */
      .relay-inline-chip__insertWrap {
        grid-column: 3;
        grid-row: 1 / 3;
        align-self: center;
        display: flex;
        align-items: center;
        gap: 6px;
        padding-right: 20px;
      }

      .relay-inline-chip__button {
        position: relative;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        gap: 6px;
        min-width: 0;
        height: 26px;
        border: none;
        border-radius: 5px;
        background: var(--relay-accent);
        color: var(--relay-accent-text);
        padding: 0 10px;
        font-size: 11px;
        font-weight: 500;
        cursor: pointer;
        white-space: nowrap;
        transition: background 120ms, opacity 120ms;
      }

      .relay-inline-chip__button:hover:not(:disabled) {
        opacity: 0.9;
      }

      .relay-inline-chip__button:disabled {
        cursor: default;
        opacity: 0.4;
      }

      .relay-inline-chip__button--loading {
        opacity: 0.7;
      }

      .relay-inline-chip__button--success {
        background: var(--relay-muted);
        color: var(--relay-accent-text);
      }

      .relay-inline-chip__shortcutKey {
        font-size: 10px;
        font-weight: 400;
        opacity: 0.5;
        margin-left: 4px;
      }

      /* \u2500\u2500 Row 2: stats (spans col 2-3) \u2500\u2500 */
      .relay-inline-chip__row2 {
        grid-column: 2 / 4;
        grid-row: 2;
        font-size: 10px;
        color: var(--relay-faint);
        line-height: 1.4;
      }

      /* \u2500\u2500 Issue tooltip \u2500\u2500 */
      .relay-inline-chip__infoWrap {
        position: relative;
        display: inline-flex;
        flex: 0 0 auto;
      }

      .relay-inline-chip__info {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        width: 14px;
        height: 14px;
        border: 1px solid var(--relay-line);
        border-radius: 999px;
        background: transparent;
        color: var(--relay-faint);
        font-size: 9px;
        font-weight: 700;
        cursor: help;
      }

      .relay-inline-chip__tooltip {
        position: absolute;
        right: 0;
        bottom: calc(100% + 6px);
        width: 220px;
        max-width: 220px;
        border-radius: 8px;
        background: var(--relay-ink);
        color: var(--relay-accent-text);
        padding: 8px 10px;
        font-size: 11px;
        line-height: 1.45;
        white-space: normal;
        overflow-wrap: anywhere;
        box-shadow: var(--relay-tooltip-shadow);
        opacity: 0;
        pointer-events: none;
        transform: translateY(-3px);
        transition: opacity 120ms ease, transform 120ms ease;
        z-index: 10;
      }

      .relay-inline-chip__infoWrap:hover .relay-inline-chip__tooltip,
      .relay-inline-chip__infoWrap:focus-within .relay-inline-chip__tooltip {
        opacity: 1;
        transform: translateY(0);
      }

      .relay-inline-chip__projectMenu,
      .relay-association-toast__projectMenu {
        display: grid;
        gap: 2px;
        padding: 6px;
        border: 1px solid var(--relay-line);
        border-radius: 8px;
        background: var(--relay-surface);
        box-shadow: 0 8px 24px rgba(0, 0, 0, 0.4);
      }

      .relay-inline-chip__projectMenu {
        position: absolute;
        bottom: calc(100% + 6px);
        left: 0;
        min-width: 180px;
        z-index: 20;
      }

      .relay-association-toast__projectMenu {
        position: absolute;
        top: 100%;
        left: 0;
        right: 0;
        margin-top: 4px;
        z-index: 10;
      }

      .relay-inline-chip__projectOption,
      .relay-association-toast__projectOption {
        width: 100%;
        display: flex;
        align-items: center;
        gap: 8px;
        border: none;
        border-radius: 6px;
        background: transparent;
        color: var(--relay-ink-secondary);
        padding: 7px 10px;
        font-size: 12px;
        text-align: left;
        cursor: pointer;
        transition: background 100ms ease;
      }

      .relay-inline-chip__projectOption:hover,
      .relay-association-toast__projectOption:hover {
        background: var(--relay-hover);
      }

      .relay-inline-chip__projectOption--active,
      .relay-association-toast__projectOption--active {
        color: var(--relay-ink);
        font-weight: 600;
      }

      @keyframes relay-shimmer {
        0% { background-position: 200% center; }
        100% { background-position: -200% center; }
      }

      .relay-inline-chip__button--loading {
        opacity: 1;
        background: var(--relay-accent);
      }

      .relay-inline-chip__shimmer {
        background: linear-gradient(90deg, #09090b 0%, #09090b 30%, rgba(255,255,255,0.6) 50%, #09090b 70%, #09090b 100%);
        background-size: 200% auto;
        -webkit-background-clip: text;
        background-clip: text;
        -webkit-text-fill-color: transparent;
        animation: relay-shimmer 2s ease-in-out infinite;
      }

      .relay-association-toast {
        --relay-bg: rgba(26, 26, 28, 0.94);
        --relay-surface: #202022;
        --relay-ink: #e4e4e7;
        --relay-ink-secondary: #b4b4bb;
        --relay-muted: #71717a;
        --relay-faint: #52525b;
        --relay-line: rgba(255, 255, 255, 0.07);
        --relay-accent: #e4e4e7;
        --relay-accent-text: #09090b;
        --relay-hover: rgba(255, 255, 255, 0.08);
        --relay-shadow: 0 12px 32px rgba(0, 0, 0, 0.35);
        position: fixed;
        top: 18px;
        right: 0;
        display: grid;
        gap: 10px;
        min-width: 220px;
        max-width: min(340px, calc(100vw - 16px));
        padding: 12px 14px 12px 14px;
        border: 1px solid var(--relay-line);
        border-top-left-radius: 14px;
        border-top-right-radius: 0;
        border-bottom-left-radius: 14px;
        border-bottom-right-radius: 0;
        border-right: none;
        background: var(--relay-bg);
        color: var(--relay-ink);
        box-shadow: var(--relay-shadow);
        font-family: system-ui, -apple-system, "Segoe UI", sans-serif;
        z-index: 2147483001;
        overflow: visible;
        opacity: 0;
        transform: translateX(100%);
        transition: opacity 200ms ease, transform 200ms ease;
      }

      .relay-association-toast[data-theme="light"] {
        --relay-bg: rgba(250, 250, 249, 0.97);
        --relay-surface: #ffffff;
        --relay-ink: #0f0f0f;
        --relay-ink-secondary: #3a3a3a;
        --relay-muted: #737373;
        --relay-faint: #a3a3a3;
        --relay-line: rgba(0, 0, 0, 0.06);
        --relay-accent: #171717;
        --relay-accent-text: #fafafa;
        --relay-hover: rgba(0, 0, 0, 0.04);
        --relay-shadow: 0 2px 8px rgba(0, 0, 0, 0.06), 0 12px 32px rgba(0, 0, 0, 0.08);
      }

      .relay-association-toast[data-theme="light"] .relay-toast-text-shimmer {
        background: linear-gradient(
          90deg,
          rgba(115, 115, 115, 0.6) 0%,
          rgba(15, 15, 15, 1) 30%,
          rgba(80, 80, 80, 1) 50%,
          rgba(15, 15, 15, 1) 70%,
          rgba(115, 115, 115, 0.6) 100%
        );
        background-size: 300% 100%;
        -webkit-background-clip: text;
        background-clip: text;
        -webkit-text-fill-color: transparent;
        color: transparent;
        animation: relay-toast-shimmer 1.8s ease-in-out infinite;
      }

      .relay-association-toast--visible {
        opacity: 1;
        transform: translateX(0);
      }

      .relay-association-toast--hiding {
        opacity: 0;
        transform: translateX(100%);
      }

      .relay-association-toast--clickable {
        cursor: pointer;
      }

      .relay-association-toast__title {
        margin: 0;
        font-size: 12px;
        font-weight: 700;
        line-height: 1.4;
      }

      .relay-toast-text-shimmer {
        background: linear-gradient(
          90deg,
          rgba(180, 180, 187, 0.5) 0%,
          rgba(228, 228, 231, 1) 30%,
          rgba(255, 255, 255, 1) 50%,
          rgba(228, 228, 231, 1) 70%,
          rgba(180, 180, 187, 0.5) 100%
        );
        background-size: 300% 100%;
        -webkit-background-clip: text;
        background-clip: text;
        -webkit-text-fill-color: transparent;
        color: transparent;
        animation: relay-toast-shimmer 1.8s ease-in-out infinite;
      }

      @keyframes relay-toast-shimmer {
        0% { background-position: 100% center; }
        100% { background-position: -100% center; }
      }

      .relay-association-toast__titleWrap {
        position: relative;
        min-width: 0;
        flex: 1;
        display: grid;
        gap: 8px;
      }

      .relay-association-toast__titleButton {
        width: fit-content;
        max-width: 100%;
        display: inline-flex;
        align-items: center;
        gap: 6px;
        border: none;
        background: transparent;
        padding: 0;
        color: inherit;
        cursor: pointer;
      }

      .relay-association-toast__titleLabel {
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
      }

      .relay-association-toast__titleChevron {
        width: 12px;
        height: 12px;
        color: var(--relay-muted);
        transition: transform 120ms ease, color 120ms ease;
      }

      .relay-association-toast__titleButton:hover .relay-association-toast__titleChevron,
      .relay-association-toast__titleButton:focus-visible .relay-association-toast__titleChevron {
        color: var(--relay-ink);
      }

      .relay-association-toast__titleButton[aria-expanded="true"] .relay-association-toast__titleChevron {
        transform: rotate(180deg);
      }

      .relay-association-toast__header {
        display: flex;
        align-items: flex-start;
        justify-content: space-between;
        gap: 12px;
      }

      .relay-association-toast__dismiss {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        width: 20px;
        height: 20px;
        flex-shrink: 0;
        border: none;
        border-radius: 999px;
        background: transparent;
        color: var(--relay-muted);
        font-size: 14px;
        cursor: pointer;
        transition: background 120ms ease, color 120ms ease;
      }

      .relay-association-toast__dismiss:hover:not(:disabled) {
        background: var(--relay-hover);
        color: var(--relay-ink);
      }

      .relay-association-toast__meta {
        margin: 0;
        font-size: 11px;
        line-height: 1.45;
        color: var(--relay-ink-secondary);
      }

      .relay-association-toast__actions {
        display: flex;
        align-items: center;
        flex-wrap: wrap;
        gap: 8px;
      }

      .relay-association-toast__button {
        width: fit-content;
        border: 1px solid var(--relay-line);
        border-radius: 999px;
        background: transparent;
        color: var(--relay-ink);
        padding: 4px 10px;
        font-size: 11px;
        font-weight: 600;
        cursor: pointer;
        transition: opacity 120ms ease, background 120ms ease, color 120ms ease;
      }

      .relay-association-toast__button:hover:not(:disabled) {
        opacity: 0.9;
      }

      .relay-association-toast__button:disabled,
      .relay-association-toast__dismiss:disabled {
        cursor: default;
        opacity: 0.45;
      }

      .relay-association-toast__button--primary {
        background: var(--relay-accent);
        color: var(--relay-accent-text);
      }

      .relay-association-toast__button--loading {
        opacity: 1;
      }

      .relay-association-toast__button--subtle {
        color: var(--relay-ink-secondary);
      }

      .relay-association-toast__timer,
      .relay-association-toast__resume {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        border: 1px solid var(--relay-line);
        border-radius: 999px;
        background: transparent;
        color: var(--relay-muted);
        cursor: pointer;
        transition: background 120ms ease, color 120ms ease, border-color 120ms ease;
      }

      .relay-association-toast__timer {
        margin-left: auto;
        min-width: 52px;
        padding: 4px 10px;
      }

      .relay-association-toast__timer:hover {
        background: var(--relay-hover);
        color: var(--relay-ink);
      }

      .relay-association-toast__timer--static {
        cursor: default;
      }

      .relay-association-toast__timer--static:hover {
        background: transparent;
        color: var(--relay-muted);
      }

      .relay-association-toast__countdown {
        font-size: 11px;
        color: inherit;
      }

      .relay-association-toast__timer-row {
        margin-left: auto;
        display: inline-flex;
        align-items: center;
        gap: 8px;
      }

      .relay-association-toast__timer-state {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        font-size: 11px;
        color: var(--relay-ink-secondary);
      }

      .relay-association-toast__timer-state svg,
      .relay-association-toast__resume svg {
        width: 11px;
        height: 11px;
      }

      .relay-association-toast__resume {
        width: 28px;
        height: 28px;
      }

      .relay-association-toast__resume:hover {
        background: var(--relay-hover);
        color: var(--relay-ink);
      }
    `,document.head.appendChild(e)}function C(){T();let e=document.getElementById("relay-inline-chip");e&&(e.classList.add("relay-inline-chip--exiting"),a.exitTimer=window.setTimeout(()=>{e.remove(),a.exitTimer=null},210))}function P(e,t,a){return Math.min(Math.max(e,t),a)}let R={chatgpt:["form"],codex:["[data-type='unified-composer']","group/composer","form"],claude:["fieldset","form","[class*='composer']","[class*='Composer']"],gemini:["input-area-v2",".input-area",".text-input-field","form"],aistudio:["ms-prompt-box","prompt-box-container","[class*='input-wrapper']","form"],perplexity:["[class*='ComposerContainer']","[class*='query-input']","form"],grok:["query-bar","form","[class*='composer']"],deepseek:["aaff8b8f","form","[class*='chat-input']"]},L=new Set(["form","fieldset","div","section","header","footer","main","nav","aside","article","textarea","input","label","button"]);function M(e){if(!e||"string"!=typeof e)return"";let t=e.trim();return t?/[\[\]#\.\>\s\*\:\,]/.test(t)?t:t.includes("/")?"."+t.replace(/\//g,"\\/"):t.includes("-")||L.has(t.toLowerCase())?t:"."+t:""}let O={};for(let e of Object.keys(R))O[e]=R[e].map(M).filter(Boolean).join(", ");function H(e){return"gemini"===e&&"undefined"!=typeof window&&window.location&&"aistudio.google.com"===window.location.hostname?"aistudio":e}let B={chatgpt:0,codex:0,claude:0,perplexity:0,gemini:0,aistudio:0,grok:0,deepseek:0},$={};try{"undefined"!=typeof chrome&&chrome.storage&&chrome.storage.local&&(chrome.storage.local.get(["relay.chipOffsets"],e=>{e&&e["relay.chipOffsets"]&&($=e["relay.chipOffsets"])}),chrome.storage.onChanged.addListener((e,t)=>{"local"===t&&e["relay.chipOffsets"]&&($=e["relay.chipOffsets"].newValue||{})}))}catch{}function N(){if(v(a.currentState))return a.currentState;if(a.pageState&&a.pageState.supported){var e;return e=a.pageState,{projectId:null,projectName:"Checking project",projectOptions:[],viewState:"connected-loading",showCue:!0,status:"updating",message:"Checking this chat\u2026",trustLine:"Built from recent chats and saved project context",freshnessText:null,shortcutLabel:navigator.userAgent.includes("Mac")?"\u2318\u21e7I":"Ctrl+Shift+I",canInsert:!1,page:e,trust:{updatedAt:null,updatedLabel:null,recentChatCount:0,savedContextCount:0},remoteStatus:"loading",issue:null,insertKind:e.isFreshChat?"fresh_chat_bootstrap":"quick_continuity",lastSuccessfulSyncAt:null,capturePending:!1,contextPreview:{decisions:[],constraints:[],tasks:[]},chatAssociation:{status:"none",projectId:null,projectName:null,sessionId:null,reason:null,capturedAt:null},routingReview:null,associationTier:"none",associationToast:{visible:!1,mode:null,projectId:null,projectName:null,projectOptions:[],sessionId:null,expiresAt:null,paused:!1},associationSuppressed:!1,insertState:{status:"idle",source:null,message:null,updatedAt:null}}}return null}function U(e){let t=e.insertState||{status:"idle",message:null};return"inserting"===t.status?{mode:"loading",message:'<span class="relay-inline-chip__shimmer">Inserting project brief\u2026</span>'}:"inserted"===t.status?{mode:"success",message:"Inserted"}:"error"===t.status&&t.message?{mode:"error",message:i(t.message)}:"loading"===a.buttonMode?{mode:"loading",message:'<span class="relay-inline-chip__shimmer">Inserting project brief\u2026</span>'}:"success"===a.buttonMode?{mode:"success",message:"Inserted"}:"error"===a.buttonMode&&a.buttonError?{mode:"error",message:i(a.buttonError)}:"updating"===e.status?{mode:"idle",message:"Updating your project brief"}:e.canInsert?{mode:"idle",message:"Insert project brief"}:{mode:"idle",message:"Project brief unavailable"}}function q(e){let t=e?.insertState;if(!t||"idle"===t.status){a.buttonMode="idle",a.buttonError="";return}if("inserting"===t.status){a.buttonMode="loading",a.buttonError="";return}if("inserted"===t.status){a.buttonMode="success",a.buttonError="";return}a.buttonMode="error",a.buttonError=t.message||"Insert failed."}function D(e){let t=function(e){let t=e?.associationToast;return t&&t.visible&&t.mode&&t.projectId&&t.projectName&&null!=t.expiresAt?{mode:t.mode,projectId:t.projectId,projectName:t.projectName,projectOptions:t.projectOptions?.length>0?t.projectOptions:e.projectOptions||[],sessionId:t.sessionId||null,expiresAt:t.expiresAt,digestStatus:t.digestStatus||null,reason:t.reason||null}:null}(e);if(!t){a.associationToast.payload&&J();return}a.associationToast.paused=e.associationToast?.paused===!0,a.associationToast.paused||(a.associationToast.remainingMs=null),ee(t)}function F(e,t,a){return e.map(e=>{let r=e.id===t;return`
          <button
            class="${a}${r?` ${a}--active`:""}"
            type="button"
            data-project-id="${i(e.id)}"
          >
            ${r?'<svg width="12" height="12" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polyline points="3 8.5 6.5 12 13 4"></polyline></svg>':'<span style="width:12px"></span>'}
            <span>${i(e.name)}</span>
          </button>
        `}).join("")}async function z(){let e=N(),t=`chip-insert-${Date.now()}-${Math.random().toString(36).slice(2,10)}`;if(!e||!e.canInsert)return j({level:"warn",area:"insert",event:"inline_insert.unavailable",flowId:t,message:e?.issue?.detail??"Project brief unavailable."}),{ok:!1,reason:e?.issue?.detail??"Project brief unavailable."};T(),a.buttonMode="loading",a.buttonError="",V();let r=await w({type:"RELAY_INSERT_PROJECT_BRIEF",payload:{source:"inline_chip",projectId:e.projectId}});if(!r||!r.ok){let n=b(p()),o=n?n.isContentEditable?s(n.element.textContent):"value"in n.element?s(n.element.value):"":"",i=o&&o.trim().length>40;return i||j({level:"warn",area:"insert",event:"inline_insert.failed",flowId:t,message:r&&r.reason?r.reason:"Insert failed from inline chip.",context:{projectId:e.projectId}}),a.buttonMode="idle",a.buttonError="",a.dismissed=!0,a.forcedInsertKind=null,C(),r}return a.buttonMode="success",a.buttonError="",V(),a.exitTimer=window.setTimeout(()=>{a.dismissed=!0,a.forcedInsertKind=null,C(),a.buttonMode="idle"},1200),j({level:"info",area:"insert",event:"inline_insert.succeeded",flowId:t,message:"Inserted project brief from the inline chip.",context:{projectId:e.projectId,projectName:e.projectName}}),r}function K(e){j({level:"info",area:"chip",event:"keyboard"===e?"inline_chip.dismissed_escape":"inline_chip.dismissed",message:"keyboard"===e?"Dismissed the inline chip with Escape.":"Dismissed the inline chip."}),a.dismissed=!0,a.forcedVisible=!1,a.forcedInsertKind=null,C()}function V(){let e;let t=p(),r=N();if(!t||!r||!(v(r)&&r.page.supported&&(r.showCue||a.forcedVisible)&&(!a.dismissed||a.forcedVisible)&&(a.forcedVisible||r.page.isFreshChat||"quick_continuity"===a.forcedInsertKind))){let e=r&&("loading"===r.remoteStatus||"stale"===r.remoteStatus);e&&document.getElementById("relay-inline-chip")||function(){T();let e=document.getElementById("relay-inline-chip");e&&e.remove()}();return}let n=(E(),(e=document.getElementById("relay-inline-chip"))||((e=document.createElement("div")).id="relay-inline-chip",e.className="relay-inline-chip relay-inline-chip--floating",document.body.appendChild(e),requestAnimationFrame(()=>{e.classList.add("relay-inline-chip--visible")})),e.dataset.theme=a.resolvedTheme,e),o=JSON.stringify({href:a.href,dismissed:a.dismissed,forcedInsertKind:a.forcedInsertKind,chipProjectSwitcherOpen:k("chip"),projectId:r.projectId,projectName:r.projectName,message:r.message,status:r.status,remoteStatus:r.remoteStatus,issue:r.issue?.detail??null,insertKind:r.insertKind,canInsert:r.canInsert,capturePending:r.capturePending,freshnessText:r.freshnessText,options:r.projectOptions.map(e=>e.id),associationStatus:r.chatAssociation.status,associationProjectId:r.chatAssociation.projectId,associationProjectName:r.chatAssociation.projectName,insertStatus:r.insertState?.status??"idle",insertMessage:r.insertState?.message??null});if(n.dataset.renderKey!==o){let e=!!r.issue&&(!r.canInsert||"stale"===r.remoteStatus||"unavailable"===r.remoteStatus),t=U(r),s=k("chip"),l=["relay-inline-chip__button","loading"===t.mode?"relay-inline-chip__button--loading":"","success"===t.mode?"relay-inline-chip__button--success":"","error"===t.mode?"relay-inline-chip__button--loading":""].filter(Boolean).join(" "),c=r.projectOptions.length>1?`
            <div class="relay-inline-chip__titleWrap">
              <button
                class="relay-inline-chip__titleButton"
                type="button"
                aria-label="Switch project"
                aria-expanded="${s?"true":"false"}"
              >
                <span class="relay-inline-chip__title relay-inline-chip__titleLabel">${i(r.projectName||"No project")}</span>
                <svg class="relay-inline-chip__titleChevron" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                  <polyline points="4 6 8 10 12 6"></polyline>
                </svg>
              </button>
              ${s?`<div class="relay-inline-chip__projectMenu">${F(r.projectOptions,r.projectId,"relay-inline-chip__projectOption")}</div>`:""}
            </div>
          `:`<div class="relay-inline-chip__titleWrap"><p class="relay-inline-chip__title">${i(r.projectName||"No project")}</p></div>`,p=i(r.shortcutLabel||(navigator.userAgent.includes("Mac")?"\u2318\u21e7I":"Ctrl+Shift+I")),d=r.trust&&(r.trust.recentChatCount>0||r.trust.savedContextCount>0)?`${i(String(r.trust.recentChatCount))} chats \u00b7 ${i(String(r.trust.savedContextCount))} saved`:i(r.trustLine||""),u=r.freshnessText?` \u00b7 ${i(r.freshnessText)}`:"",m="undefined"!=typeof chrome&&chrome.runtime?chrome.runtime.getURL("assets/relay_logo_white.png"):"";n.innerHTML=`
        <div class="relay-inline-chip__body">
          <button class="relay-inline-chip__close" type="button" aria-label="Dismiss">\u00d7</button>
          <img class="relay-inline-chip__logo" src="${i(m)}" alt="Relay" />
          <div class="relay-inline-chip__row1">
            ${c}
          </div>
          <div class="relay-inline-chip__insertWrap">
            ${e?`<div class="relay-inline-chip__infoWrap">
                    <button class="relay-inline-chip__info" type="button" aria-label="Details">i</button>
                    <div class="relay-inline-chip__tooltip">${i(r.issue.detail)}</div>
                  </div>`:""}
            <button class="${l}" type="button" ${r.canInsert&&"loading"!==t.mode?"":"disabled"}>
              ${U(r).message}<span class="relay-inline-chip__shortcutKey">${p}</span>
            </button>
          </div>
          <div class="relay-inline-chip__row2">
            ${d}${u}
          </div>
        </div>
      `;let h=n.querySelector(".relay-inline-chip__close");h&&h.addEventListener("click",()=>{K("button")});let f=n.querySelector(".relay-inline-chip__button");f&&f.addEventListener("click",async()=>{await z()});let g=n.querySelector(".relay-inline-chip__titleButton");g&&g.addEventListener("click",e=>{e.preventDefault(),e.stopPropagation(),I("chip")}),n.querySelectorAll(".relay-inline-chip__projectOption").forEach(e=>{e.addEventListener("click",async t=>{t.preventDefault(),t.stopPropagation();let n=e.getAttribute("data-project-id");if(!n)return;let o=r.chatAssociation&&["pending","held","saved"].includes(r.chatAssociation.status);j({level:"info",area:"project",event:o?"inline_association.retarget":"inline_project.switch",message:o?"Retargeted the chat association from the inline chip.":"Switched the active project from the inline chip.",context:{projectId:n}}),a.buttonMode="idle",a.buttonError="",S(),await w(o?{type:"RELAY_SET_CHAT_ASSOCIATION_PROJECT",payload:{projectId:n,source:"inline_chip"}}:{type:"RELAY_SET_ACTIVE_PROJECT",payload:{projectId:n}})})}),n.dataset.renderKey=o}n.classList.contains("relay-inline-chip--visible")||requestAnimationFrame(()=>{n.classList.add("relay-inline-chip--visible")}),n.classList.remove("relay-inline-chip--exiting"),function(e,t){let a=b(e);if(!a){t.classList.remove("relay-inline-chip--anchored"),t.classList.add("relay-inline-chip--floating"),t.style.left="",t.style.top="",t.style.width="";return}let r=a.element.getBoundingClientRect(),n=function(e,t){let a=H(t),r=O[a];if(r)try{let t=e.closest(r);if(t)return t}catch{}try{let t=e.getBoundingClientRect(),a=e.parentElement,r=e,n=0;for(;a&&n<10;){let e=a.getBoundingClientRect();if(e.width>.95*window.innerWidth)break;e.height>t.height+24&&e.top<=t.top&&(r=a),a=a.parentElement,n+=1}return r}catch{return e}}(a.element,e.platform),o=n.getBoundingClientRect(),i=P(r.width,280,Math.min(600,window.innerWidth-32));t.style.width=`${Math.round(i)}px`;let s=t.offsetHeight||200,l=P(r.left+(r.width-i)/2,16,Math.max(16,window.innerWidth-i-16)),c=H(e.platform),p=($&&$[c])??B[c]??-4,d=o.top-s+p;d<16&&(d=o.bottom+Math.abs(p)),d+s>window.innerHeight-16&&(d=Math.max(16,window.innerHeight-s-16)),t.classList.remove("relay-inline-chip--floating"),t.classList.add("relay-inline-chip--anchored"),t.style.left=`${Math.round(l)}px`,t.style.top=`${Math.round(d)}px`}(t,n)}function Y(){let e=a.associationToast;null!==e.hideTimer&&(window.clearTimeout(e.hideTimer),e.hideTimer=null),null!==e.removeTimer&&(window.clearTimeout(e.removeTimer),e.removeTimer=null),null!==e.countdownTimer&&(window.clearInterval(e.countdownTimer),e.countdownTimer=null)}function G(e){return e?`${e.mode}:${e.projectId}`:""}function W(){a.associationToast.paused=!1,a.associationToast.remainingMs=null}function J(){Y();let e=document.getElementById("relay-association-toast");if(k("toast")&&S(),W(),!e){a.associationToast.payload=null;return}e.classList.add("relay-association-toast--hiding"),a.associationToast.removeTimer=window.setTimeout(()=>{e.remove(),a.associationToast.removeTimer=null,a.associationToast.payload=null,W()},180)}function Z(e){return`${Math.max(0,Math.ceil((e-Date.now())/1e3))}s`}function Q(e,t){let a=e.querySelector(".relay-association-toast__countdown");a&&(a.textContent=Z(t.expiresAt))}async function X(e,t,r){var n;if(e.dataset.pendingAction)return;let o=(n=t,null!==a.associationToast.remainingMs?Math.max(0,a.associationToast.remainingMs):Math.max(0,n.expiresAt-Date.now()));if(a.associationToast.remainingMs=o,a.associationToast.paused=r,Y(),"auto_save"===t.mode){let e=await w({type:"RELAY_SET_ASSOCIATION_TOAST_PAUSED",payload:{paused:r,mode:t.mode,projectId:t.projectId}});if(e?.ok===!1){a.associationToast.remainingMs=null,a.associationToast.paused=!1,ee(t);return}"number"==typeof e?.expiresAt?t={...t,expiresAt:e.expiresAt}:r||(t={...t,expiresAt:Date.now()+o})}else r||(t={...t,expiresAt:Date.now()+o});r||(a.associationToast.remainingMs=null),ee(t)}function ee(e){E();let t=a.associationToast.payload;G(t)!==G(e)&&W(),a.associationToast.payload=e,Y();let r=document.getElementById("relay-association-toast");r||((r=document.createElement("div")).id="relay-association-toast",r.className="relay-association-toast",document.body.appendChild(r)),r.dataset.theme=a.resolvedTheme,delete r.dataset.pendingAction;let n="saving"===e.mode?`Saving to ${e.projectName}`:"done"===e.mode?"analyzed"===e.digestStatus?"Saved & analyzed":"queued"===e.digestStatus?"Saved - analysis queued":`Saved to ${e.projectName}`:`Approve save to ${e.projectName}`,o="saving"===e.mode?e.reason||`Saving this chat to ${e.projectName}...`:"done"===e.mode?"analyzed"===e.digestStatus?"Chat captured and your project brief is being updated.":"queued"===e.digestStatus?"Chat captured. Analysis will run shortly.":"Chat captured to your project.":e.reason||"Relay is not fully sure. Approve now or review it later in the sidebar.",s="ask"===e.mode,l="done"!==e.mode,c="ask"===e.mode&&e.projectOptions&&e.projectOptions.length>1,p=k("toast"),d=c?`
          <div class="relay-association-toast__titleWrap">
            <button
              class="relay-association-toast__titleButton"
              type="button"
              aria-label="Switch association project"
              aria-expanded="${p?"true":"false"}"
            >
              <span class="relay-association-toast__title relay-association-toast__titleLabel ${"saving"===e.mode?"relay-toast-text-shimmer":""}">${i(n)}</span>
              <svg class="relay-association-toast__titleChevron" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                <polyline points="4 6 8 10 12 6"></polyline>
              </svg>
            </button>
            ${p?`<div class="relay-association-toast__projectMenu">${F(e.projectOptions,e.projectId,"relay-association-toast__projectOption")}</div>`:""}
          </div>
        `:`<p class="relay-association-toast__title ${"saving"===e.mode?"relay-toast-text-shimmer":""}">${i(n)}</p>`;r.classList.toggle("relay-association-toast--clickable",!1),r.innerHTML=`
      <div class="relay-association-toast__header">
        ${d}
        ${l?'<button class="relay-association-toast__dismiss" type="button" aria-label="Dismiss association toast">\xd7</button>':""}
      </div>
      <p class="relay-association-toast__meta">${i(o)}</p>
      ${s?`<div class="relay-association-toast__actions">
        <button class="relay-association-toast__button relay-association-toast__button--primary" type="button" data-action="approve">Approve save</button><button class="relay-association-toast__button relay-association-toast__button--subtle" type="button" data-action="cancel">Not this chat</button>
        ${e.expiresAt<=0?"":a.associationToast.paused?`
        <div class="relay-association-toast__timer-row">
          <span class="relay-association-toast__timer-state">
            
      <svg viewBox="0 0 16 16" fill="none" aria-hidden="true">
        <rect x="4" y="3" width="2.5" height="10" rx="1.25" fill="currentColor"></rect>
        <rect x="9.5" y="3" width="2.5" height="10" rx="1.25" fill="currentColor"></rect>
      </svg>
    
            Paused
          </span>
          <button class="relay-association-toast__resume" type="button" aria-label="Resume association toast timer">
            
      <svg viewBox="0 0 16 16" fill="none" aria-hidden="true">
        <path d="M5 3.5L12 8L5 12.5V3.5Z" fill="currentColor"></path>
      </svg>
    
          </button>
        </div>
      `:`
      <button class="relay-association-toast__timer" type="button" aria-label="Pause auto-save timer">
        <span class="relay-association-toast__countdown">${Z(e.expiresAt)}</span>
      </button>
    `}
      </div>`:""}
    `,r.onclick=null;let u=r.querySelector(".relay-association-toast__titleButton");u&&u.addEventListener("click",e=>{e.preventDefault(),e.stopPropagation(),I("toast")}),r.querySelectorAll(".relay-association-toast__projectOption").forEach(t=>{t.addEventListener("click",async a=>{if(a.preventDefault(),a.stopPropagation(),r.dataset.pendingAction)return;let n=t.getAttribute("data-project-id");if(!n||n===e.projectId)return;let o=await w({type:"RELAY_SET_CHAT_ASSOCIATION_PROJECT",payload:{projectId:n,source:"toast"}});if(!o?.ok){ee(e);return}S(),ee({...e,projectId:o.projectId??n,projectName:o.projectName??e.projectName,projectOptions:o.state?.projectOptions??e.projectOptions})})}),r.querySelectorAll("[data-action]").forEach(t=>{t.addEventListener("click",async a=>{a.preventDefault(),a.stopPropagation();let n=t.getAttribute("data-action");if(!n||r.dataset.pendingAction)return;"approve"===n&&function(e,t){e.dataset.pendingAction="approve";let a=e.querySelector(".relay-association-toast__meta");a&&(a.textContent=`Saving this chat to ${t.projectName}\u2026`);let r=e.querySelectorAll(".relay-association-toast__button, .relay-association-toast__dismiss");r.forEach(e=>{e.disabled=!0});let n=e.querySelector('[data-action="approve"]');n&&(n.textContent="Approving\u2026",n.classList.add("relay-association-toast__button--loading"));let o=e.querySelector(".relay-association-toast__countdown");o&&(o.textContent="Saving\u2026")}(r,e);let o=await w({type:"RELAY_RESOLVE_ASSOCIATION_TOAST",payload:{action:n,mode:e.mode,projectId:e.projectId}});if(o?.ok===!1&&"approve"===n){ee(e);return}"approve"!==n&&J()})});let m=r.querySelector(".relay-association-toast__dismiss");m&&m.addEventListener("click",async t=>{if(t.preventDefault(),t.stopPropagation(),!r.dataset.pendingAction){if("saving"===e.mode){J();return}await w({type:"RELAY_RESOLVE_ASSOCIATION_TOAST",payload:{action:"cancel",mode:e.mode,projectId:e.projectId}}),J()}}),requestAnimationFrame(()=>{r.classList.remove("relay-association-toast--hiding"),r.classList.add("relay-association-toast--visible")});let h="auto_save"===e.mode?r.querySelector(".relay-association-toast__timer"):null;h&&h.addEventListener("click",t=>{t.preventDefault(),t.stopPropagation(),a.associationToast.paused||X(r,e,!0)});let f=r.querySelector(".relay-association-toast__resume");f&&f.addEventListener("click",t=>{t.preventDefault(),t.stopPropagation(),X(r,e,!1)}),a.associationToast.paused||(Q(r,e),a.associationToast.countdownTimer=window.setInterval(()=>{Q(r,e)},250))}async function et(e){var t;let r;let n=window.location.href;a.href!==n&&(a.href=n,a.dismissed=!1,a.forcedVisible=!1,a.forcedInsertKind=null,S(),a.buttonMode="idle",a.buttonError="",a.currentState=null,a.lastPageStateKey="",a.freshCandidateSince=0,T(),J());try{let e=p();console.debug("[Relay] getSiteConfig() \u2192",e),r=_(e)}catch(e){console.debug("[Relay] computePageState threw:",e),j({level:"error",area:"runtime",event:"inline_chip.compute_page_state_error",message:"computePageState threw during observation.",error:{message:String(e&&e.message||e)}}),r={supported:!1}}console.debug("[Relay] pageState \u2192",{supported:r.supported,platform:r.platform,routeKind:r.routeKind}),a.pageState=r;let o=r.supported&&r.isStreaming;a.wasStreaming&&!o&&(a.streamingEndedAt=Date.now(),null!==a.stabilityRecheckTimer&&window.clearTimeout(a.stabilityRecheckTimer),a.stabilityRecheckTimer=window.setTimeout(()=>{a.stabilityRecheckTimer=null,ea(!1)},800)),o&&(a.streamingEndedAt=0),a.wasStreaming=!!o;let i=JSON.stringify({supported:(t=r).supported,routeKind:t.routeKind,url:t.url,sourceConversationId:t.sourceConversationId,turns:t.turns,captureSignature:t.captureSignature,recentUserTurnText:t.recentUserTurnText,recentRoutingText:t.recentRoutingText,fullVisibleRoutingText:t.fullVisibleRoutingText,promptReady:t.promptReady,isFreshRoute:t.isFreshRoute,isFreshChat:t.isFreshChat,isStable:t.isStable,isStreaming:t.isStreaming});(e||a.lastPageStateKey!==i)&&(a.lastPageStateKey=i,await w({type:"RELAY_PAGE_STATE_UPDATE",payload:r})),V()}function ea(e){null===a.observationTimer&&(a.observationTimer=window.setTimeout(()=>{a.observationTimer=null,et(e)},120))}chrome.runtime.onMessage.addListener((e,t,r)=>{if("RELAY_ACTIVE_PROJECT_STATE_CHANGED"===e.type)return a.currentState=e.payload.state,q(e.payload.state),D(e.payload.state),V(),!1;if("RELAY_EXTENSION_THEME_CHANGED"===e.type)return n(e.payload?.theme||"system"),!1;if("RELAY_PAGE_STATE"===e.type){let e;try{e=a.pageState??_(p())}catch(t){e={supported:!1}}return a.pageState=e,r(e),!0}if("RELAY_SHOW_INLINE_CHIP"===e.type){let t=a.pageState??_(p());if(!t.supported)return r({ok:!1,status:"fallback"}),!0;a.forcedInsertKind=e.payload?.insertKind==="quick_continuity"?"quick_continuity":null;let n=a.dismissed;return a.dismissed=!1,V(),j({level:"info",area:"chip",event:"inline_chip.shown",message:"Requested to show the inline chip.",context:{restored:n,insertKind:e.payload?.insertKind==="quick_continuity"?"quick_continuity":"fresh_chat_bootstrap"}}),w({type:"RELAY_GET_ACTIVE_PROJECT_STATE"}).then(e=>{v(e)&&(a.currentState=e,q(e),D(e),V())}),r({ok:!0,status:n?"restored":document.getElementById("relay-inline-chip")?"already_visible":"newly_opened"}),!0}if("RELAY_SHOW_ASSOCIATION_TOAST"===e.type)return S(),ee(e.payload),r({ok:!0}),!0;if("RELAY_SHORTCUT_ACTION"===e.type){let e=a.pageState??_(p());if(a.pageState=e,!e.supported||!1===e.promptReady)return r({ok:!0,action:"fallback"}),!0;let t=!!document.getElementById("relay-inline-chip");if(t)return j({level:"info",area:"shortcut",event:"inline_chip.shortcut_insert",message:"Shortcut triggered project brief insertion from a visible chip."}),z(),r({ok:!0,action:"invoked_insert"}),!0;if(e.isFreshChat){let e=a.dismissed?"restored":"opened";return j({level:"info",area:"shortcut",event:"inline_chip.shortcut_opened",message:"Shortcut opened the inline chip on a fresh chat.",context:{action:e}}),a.forcedInsertKind=null,a.dismissed=!1,a.forcedVisible=!0,V(),w({type:"RELAY_GET_ACTIVE_PROJECT_STATE"}).then(e=>{v(e)&&(a.currentState=e,q(e),D(e),V())}),r({ok:!0,action:e}),!0}return a.forcedInsertKind="quick_continuity",a.dismissed=!1,a.forcedVisible=!0,j({level:"info",area:"shortcut",event:"inline_chip.shortcut_quick_continuity",message:"Shortcut opened the inline chip in quick continuity mode."}),V(),w({type:"RELAY_GET_ACTIVE_PROJECT_STATE"}).then(e=>{v(e)&&(a.currentState=e,q(e),D(e),V())}),r({ok:!0,action:"opened"}),!0}if("RELAY_CAPTURE_VISIBLE"===e.type){let e=p();if(!e)return r({ok:!1,reason:"Unsupported site."}),!0;let t=f(),a=d(e,t),n=m(a),o=g(e.platform,t);return r({ok:!0,capture:{platform:e.platform,session:{title:t.title,url:t.url,pageFingerprint:t.pageFingerprint,sourceConversationId:o,captureSignature:c(n,t,e.platform,o),metadata:{domain:t.domain,pathname:t.pathname}},turns:n}}),!0}if("RELAY_GET_SELECTION"===e.type){let e=p();if(!e)return r({ok:!1,reason:"Unsupported site."}),!0;let t=s(window.getSelection?window.getSelection().toString():"");if(!t)return r({ok:!1,reason:"Select text in the page first."}),!0;let a=f();return r({ok:!0,text:t,platform:e.platform,metadata:{url:a.url,title:a.title,pathname:a.pathname}}),!0}if("RELAY_INSERT_CONTEXT"===e.type){let t=p();return t?x(t,e.payload.content).then(r):r({ok:!1,reason:"Unsupported site."}),!0}return!1}),window.addEventListener("error",e=>{j({level:"error",area:"runtime",event:"inline_chip.error",message:e.message||"Unhandled content-script error.",error:e.error?{message:String(e.error.message||e.error),stack:e.error.stack||null}:{message:e.message||"Unhandled content-script error."}})}),window.addEventListener("unhandledrejection",e=>{j({level:"error",area:"runtime",event:"inline_chip.unhandled_rejection",message:"Unhandled content-script promise rejection.",error:{message:String(e.reason)}})}),window.matchMedia("(prefers-color-scheme: dark)").addEventListener("change",()=>{"system"===a.themeMode&&n("system")}),window.addEventListener("message",e=>{if(e.source!==window||e.data?.type!=="RELAY_NETWORK_CAPTURE")return;let t=e.data.payload;t&&"string"==typeof t.platform&&Array.isArray(t.turns)&&(r.latest={platform:t.platform,conversationId:t.conversationId??null,title:t.title??null,url:t.url??"",turns:t.turns,capturedAt:t.capturedAt??Date.now()},window.__RELAY_DEBUG&&console.log("[Relay] Network capture received:",t.platform,t.turns.length,"turns"))}),o(),function(){if(a.mounted)return;a.mounted=!0,ea(!0);let e=new MutationObserver(e=>{let t=e.some(e=>{let t=e.target;return!(t instanceof Element&&t.closest("#relay-inline-chip"))&&[...e.addedNodes,...e.removedNodes].some(e=>!(e instanceof Element)||!e.closest("#relay-inline-chip"))});t&&(a.lastMeaningfulMutationAt=Date.now(),ea(!1),null!==a.stabilityRecheckTimer&&window.clearTimeout(a.stabilityRecheckTimer),a.stabilityRecheckTimer=window.setTimeout(()=>{a.stabilityRecheckTimer=null,ea(!1)},1900))});e.observe(document.body,{childList:!0,subtree:!0,characterData:!0}),window.addEventListener("keydown",e=>{"Escape"===e.key&&!e.metaKey&&!e.ctrlKey&&!e.altKey&&!e.shiftKey&&document.getElementById("relay-inline-chip")&&(e.preventDefault(),K("keyboard"))}),window.addEventListener("focus",()=>ea(!1)),window.addEventListener("pointerdown",e=>{if(!a.projectSwitcherSurface)return;let t=e.target;t instanceof Element&&(t.closest(".relay-inline-chip__titleButton")||t.closest(".relay-inline-chip__projectMenu")||t.closest(".relay-association-toast__titleButton")||t.closest(".relay-association-toast__projectMenu")||(S(),A()))}),window.addEventListener("resize",()=>ea(!1)),window.addEventListener("popstate",()=>{a.lastMeaningfulMutationAt=Date.now(),ea(!0)}),["pushState","replaceState"].forEach(function(e){var t=window.history[e];"function"==typeof t&&(window.history[e]=function(){var e=t.apply(this,arguments);return a.lastMeaningfulMutationAt=Date.now(),ea(!0),e})}),window.setInterval(()=>{ea(!1)},1e3)}()}()},{}]},["eOyul"],"eOyul","parcelRequireceae"),globalThis.define=t;